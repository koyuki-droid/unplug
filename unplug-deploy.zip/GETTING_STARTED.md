# Getting Started Guide

This guide will help you set up and run the Unplug Data Vault application.

## Prerequisites

- Node.js 18+ installed
- npm or yarn package manager
- MetaMask or compatible Web3 wallet installed in your browser
- A Web3.Storage account (for IPFS storage) - free at https://web3.storage/
- A WalletConnect Project ID (for RainbowKit) - free at https://cloud.walletconnect.com/

## Step 1: Install Dependencies

```bash
npm install
```

## Step 2: Set Up Environment Variables

Create a `.env.local` file in the root directory:

```bash
# Web3.Storage API Token (for IPFS)
NEXT_PUBLIC_WEB3_STORAGE_TOKEN=your_web3_storage_token_here

# WalletConnect Project ID (for RainbowKit)
NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID=your_walletconnect_project_id_here

# Contract Addresses (will be set after deployment)
NEXT_PUBLIC_DATA_VAULT_ADDRESS=
NEXT_PUBLIC_PERMISSION_MANAGER_ADDRESS=
NEXT_PUBLIC_MICRO_ECONOMY_ADDRESS=
NEXT_PUBLIC_ACCESS_CONTROL_ADDRESS=

# Network Configuration
NEXT_PUBLIC_NETWORK=localhost
NEXT_PUBLIC_CHAIN_ID=1337
```

## Step 3: Start Local Blockchain

In one terminal, start Hardhat local network:

```bash
npx hardhat node
```

This will start a local Ethereum node on `http://127.0.0.1:8545`.

## Step 4: Deploy Smart Contracts

In another terminal, deploy contracts to local network:

```bash
npm run deploy:local
```

This will:
- Deploy all smart contracts to the local blockchain
- Save contract addresses to `contracts/addresses.json`
- Update your `.env.local` with the contract addresses (you'll need to copy them manually)

After deployment, copy the contract addresses from `contracts/addresses.json` to your `.env.local` file.

## Step 5: Configure MetaMask

1. Open MetaMask
2. Add a custom network:
   - Network Name: `Hardhat Local`
   - RPC URL: `http://127.0.0.1:8545`
   - Chain ID: `1337`
   - Currency Symbol: `ETH`
3. Import one of the Hardhat test accounts:
   - When you run `npx hardhat node`, it will show test accounts with private keys
   - Copy a private key and import it into MetaMask

## Step 6: Start the Frontend

In another terminal, start the Next.js development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Step 7: Connect Your Wallet

1. Click "Connect Wallet" in the top right
2. Select MetaMask
3. Approve the connection

## Usage

### Upload Data

1. Go to the "Upload" tab
2. Select a data type (e.g., "Medical Record")
3. Choose a file (PDF, DOCX, or image)
4. Click "Upload to Vault"
5. Sign the transaction with MetaMask
6. Your file is encrypted and stored on IPFS
7. The IPFS hash is recorded on the blockchain

### Grant Permissions

1. Go to the "Permissions" tab
2. Enter the record ID you want to share
3. Enter the recipient's Ethereum address
4. Choose permission type (Read, Write, or AI Access)
5. Set duration (in days)
6. Click "Sign & Grant Permission"
7. Sign the permission message (MetaMask-style signature)
8. Permission is granted with automatic expiry

### Monetize Data (Micro-Economy)

1. Grant "AI Access" permission to an AI company
2. Set payment terms (payment per time interval)
3. AI company can make payments for data access
4. Payments accumulate in your balance
5. Permission auto-expires when time is up
6. Withdraw earnings anytime

## Smart Contracts Overview

- **DataVault**: Stores data metadata and IPFS hashes on blockchain
- **PermissionManager**: Manages time-limited permissions with signature-based auth
- **MicroEconomy**: Handles payments for data access permissions
- **AccessControl**: Coordinates access between vault and permissions

## Architecture

- **Frontend**: Next.js 14 with React, TypeScript, TailwindCSS
- **Blockchain**: Ethereum (Solidity smart contracts via Hardhat)
- **Storage**: IPFS via Web3.Storage (decentralized, immutable)
- **Wallet**: MetaMask/RainbowKit integration
- **Signatures**: ECDSA signatures for permission granting (MetaMask-style)

## Security Features

- All data is encrypted before IPFS upload (TODO: implement encryption layer)
- Time-limited permissions that auto-expire
- Signature-based authentication (like MetaMask)
- Self-custody - you own your keys and data
- Immutable blockchain records
- Censorship-resistant IPFS storage

## Next Steps

- Implement client-side encryption before IPFS upload
- Add file decryption when downloading
- Implement full contract integration in React components
- Add more data types and categories
- Build API for third-party integrations
- Add mobile app support

## Troubleshooting

**Contracts not deploying?**
- Make sure Hardhat node is running
- Check that you have ETH in your deployer account

**Wallet connection issues?**
- Ensure MetaMask is installed
- Check network is set to localhost (Chain ID 1337)
- Try refreshing the page

**IPFS upload failing?**
- Verify your Web3.Storage token is correct
- Check your API quota at web3.storage

## License

MIT

