# How to Get GitHub Personal Access Token

## Step-by-Step Instructions

### Step 1: Go to Token Settings
1. **Login to GitHub** as `koyuki-droid`
2. Click your **profile picture** (top right)
3. Click **Settings**

### Step 2: Navigate to Developer Settings
1. Scroll down in the left sidebar
2. Click **Developer settings** (at the bottom)

### Step 3: Create Token
1. Click **Personal access tokens** (under Developer settings)
2. Click **Tokens (classic)** or **Fine-grained tokens**
3. Click **Generate new token** → **Generate new token (classic)**

### Step 4: Configure Token
1. **Note**: Give it a name like `unplug-deployment`
2. **Expiration**: Choose duration (90 days, 1 year, or no expiration)
3. **Select scopes**: Check the **`repo`** checkbox (this selects all repo permissions)

### Step 5: Generate & Copy
1. Scroll down and click **Generate token** (green button at bottom)
2. **IMPORTANT**: Copy the token immediately - you'll only see it once!
   - It looks like: `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

### Step 6: Use the Token
Once you have the token, use it to push:

```bash
cd /Users/koyukinakamori/unplug
git remote set-url origin https://koyuki-droid:YOUR_TOKEN@github.com/koyuki-droid/unplug.git
git push -u origin main
```

**Replace `YOUR_TOKEN` with the actual token you copied!**

## Quick Links

- **Token Settings**: https://github.com/settings/tokens
- **Direct Link to Create Token**: https://github.com/settings/tokens/new

## Security Notes

⚠️ **Keep your token secret!** Never share it or commit it to git.
- If you accidentally commit it, revoke it immediately and create a new one
- Tokens act as passwords - treat them the same way

## Alternative: Token in Git Credential Helper

Instead of putting token in URL, you can also:

```bash
# Store token securely
git credential-osxkeychain store
# Then enter:
# protocol=https
# host=github.com
# username=koyuki-droid
# password=YOUR_TOKEN
```

